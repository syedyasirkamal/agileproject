# -*- coding: utf-8 -*-
import unittest

from gilded_rose import Item, GildedRose

# Test - Brian, Andrew yasir
class GildedRoseTest(unittest.TestCase):
    def test_foo(self):
        items = [Item("foo", 0, 0)]
        gilded_rose = GildedRose(items)
        gilded_rose.update_quality()
        self.assertEqual("foo", items[0].name)
        self.assertEqual(-1, items[0].sell_in)
        self.assertEqual(0, items[0].quality)
#aged-brie must go up in quality as sell-in increases
    def test_agedbrie(self):
        items = [Item("Aged Brie", 0, 25)]
        gilded_rose = GildedRose(items)
        gilded_rose.update_quality()
        self.assertEqual(-1, items[0].sell_in)
        self.assertEqual(27, items[0].quality)

#quality never greater than 50
    def test_qualitygreaterthan50(self):
        items = [Item("Aged Brie", -1, 50)]
        gilded_rose = GildedRose(items)
        gilded_rose.update_quality()
        self.assertEqual(50, items[0].quality)

#"Sulfuras", being a legendary item, never has to be sold or decreases in Quality; actually decreases
    def test_sulfuras(self):
        items = [Item("Sulfuras", -1, 25)]
        gilded_rose = GildedRose(items)
        gilded_rose.update_quality()
        self.assertEqual(-2, items[0].sell_in)
        self.assertEqual(23, items[0].quality)

#"Backstage passes", like aged brie, increases in Quality as its SellIn value approaches; Actually decreases
    def test_Backstagepasses(self):
        items = [Item("Backstage passes", 0, 25)]
        gilded_rose = GildedRose(items)
        gilded_rose.update_quality()
        self.assertEqual(-1, items[0].sell_in)
        self.assertEqual(23, items[0].quality)

# Assertion: Quality increases by 2 when 10 days or less
# Outcome: Quality decreased by 1
    def test_Qualinc10(self):
        items = [Item("Backstage passes", 10, 25)]
        gilded_rose = GildedRose(items)
        gilded_rose.update_quality()
        self.assertEqual(9, items[0].sell_in)
        self.assertEqual(24, items[0].quality)


    def test_Qualinc5(self):
        items = [Item("Backstage passes", 5, 25)]
        gilded_rose = GildedRose(items)
        gilded_rose.update_quality()
        self.assertEqual(4, items[0].sell_in)
        self.assertEqual(28, items[0].quality)

    def test_Afterconcert(self):
        items = [Item("Backstage passes", 0, 25)]
        gilded_rose = GildedRose(items)
        gilded_rose.update_quality()
        self.assertEqual(-1, items[0].sell_in)
        self.assertEqual(23, items[0].quality)
        
if __name__ == '__main__':
    unittest.main()

